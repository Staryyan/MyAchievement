# README
运行代码

```
npm install
cd ./bin
node www.js
```
然后点击 [Simple_Server](http://localhost:8000/)

本网站使用文件读写实现数据保存，使用Jade渲染引擎。



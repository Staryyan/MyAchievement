/**
 * Created by yanzexin on 16/11/11.
 */
$(document).ready(function () {
    $('#btn').bind('click', function () {
        window.location.href = '/';
    });
});

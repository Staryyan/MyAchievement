$(document).ready(function () {

    var Register = function () {
        $('#name').bind('blur', this.checkName);
        $('#id').bind('blur', this.checkId);
        $('#tel').bind('blur', this.checkTel);
        $('#email').bind('blur', this.checkEmail);
        $('#submit').bind('click', this.submit.bind(this));
    };
    
    var pro = Register.prototype;
    
    pro.checkName = function () {
        var format = /^[a-zA-Z]([a-zA-Z0-9_]){5,17}/;
        var elem = $('#name');
        if (!elem.val().match(format)) {
            elem.addClass('wrong').attr('placeholder', 'Shouldn\'t be empty');
            $('#tip').html('Name should be 6-18 character, number or underline and start with character!');
            return false;
        }
        elem.removeClass('wrong').attr('placeholder', 'Name');
        $('#tip').html('');
        return true;
    };

    pro.checkId = function () {
        var format = /^[1-9][0-9]{7}/;
        var elem = $('#id');
        if (!elem.val().match(format)) {
            elem.addClass('wrong').attr('placeholder', 'Shouldn\'t be empty');
            $('#tip').html('Id should be 8 number.');
            return false;
        }
        elem.removeClass('wrong').attr('placeholder', 'Id');
        $('#tip').html('');
        return true;
    };

    pro.checkTel = function () {
        var format = /^[1-9][0-9]{10}/;
        var elem = $('#tel');
        if (!elem.val().match(format)) {
            elem.addClass('wrong').attr('placeholder', 'Shouldn\'t be empty');
            $('#tip').html('Tel should be 11 number.');
            return false;
        }
        elem.removeClass('wrong').attr('placeholder', 'Tel');
        $('#tip').html('');
        return true;
    };

    pro.checkEmail = function () {
        var format = /^[a-zA-Z_\-]+[a-zA-Z_\-0-9]*@(([a-zA-Z_\-])+\.)+[a-zA-Z]{2,4}$/;
        var elem = $('#email');
        if (!elem.val().match(format)) {
            elem.addClass('wrong').attr('placeholder', 'Shouldn\'t be empty');
            $('#tip').html('Please check your email format.');
            return false;
        }
        elem.removeClass('wrong').attr('placeholder', 'Email');
        return true;
    };

    pro.submit = function () {
        if (this.checkName() && this.checkId() && this.checkTel() && this.checkEmail()) {
            console.log('submit');
            $('#submit').attr('type', 'submit');
        } else {
            $('#submit').attr('type', 'button');
        }
    };
    
    $(new Register());
});

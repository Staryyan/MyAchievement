/**
 * Controller.
 * 导入模板, 不会造成全局污染.
 */
var http = require('http');
var fs = require('fs');
var path = require('path');
var mime = require('mime');
var url = require('url');
var jade = require('jade');
var formidable = require('formidable');
var queryString = require('queryString');

var App = function (request, response) {
	this.import();
	this.cache = {};
	this.parseURL(request, response);
};

pro = App.prototype;

pro.import = function () {
	var data = fs.readFileSync("../bin/data.txt","utf-8");
	this.users = JSON.parse(data);
};

pro.sync = function () {
	fs.writeFileSync('../bin/data.txt', JSON.stringify(this.users), 'utf-8');
};

pro.parseURL = function (request, response) {
	if (request.url == '/') {
		this.serveStatic(response, this.cache, '../views/signUp.html');
	} else if (url.parse(request.url).pathname == '/signUp') {
		this.post(request, response);
	} else if (request.url.toString().indexOf('/?username') != -1) {
		this.get(request, response);
	} else {
		this.staticFile(request, response);
	}
};

pro.serveStatic = function (response, cache, absPath) {
	var that = this;
	if (this.cache[absPath]) {
		this.sendFile(response, absPath, this.cache[absPath]);
	} else {
		fs.exists(absPath, function (exists) {
			if (exists) {
				fs.readFile(absPath, function(err, data) {
					if (err) { console.log(err); }
					else {
						that.cache[absPath] = data;
						that.sendFile(response, absPath, data);
					}
				});
			} else { that.send404(response, 'Can\'t Find Resource!'); }
		});
	}
};

pro.send404 = function (response, reason) {
	fs.readFile('../views/404.html', function (err, data) {
		if (err) console.log(err);
		else {
			response.writeHead(200, {'Content-type': 'text/html'});
			data =  data.toString().replace('{reason}', reason);
			response.end(data.toString());
		}
	});
};

pro.sendFile = function (response, filePath, fileContent) {
	response.writeHead(200, {'Content-type': mime.lookup(path.basename(filePath))});
	response.end(fileContent);
};

pro.post = function (request, response) {
	if (request.method.toLowerCase() == 'post') {
		var form = formidable.IncomingForm();
		var that = this;
		form.parse(request, function (err, field) {
			if (err) {
				console.log(err);
				that.send404(response, "Connect failed!");
			} else {
				if (that.uploadInfo(response, field)) {
					that.renderInfo(field, response);
				}
			}
		});
	}
};

pro.renderInfo = function (field, response) {
	var that = this;
	fs.readFile('../views/info.html', function (err, data) {
		if (err) { that.send404(response, 'Connect Fail!')}
		else {
			data = data.toString().replace('{name}', field['name']);
			data = data.toString().replace('{id}', field['id']);
			data = data.toString().replace('{tel}', field['tel']);
			data = data.toString().replace('{email}', field['email']);
			response.writeHead(200, {'Content-type': 'text/html'});
			response.end(data.toString());
		}
	});
};

pro.uploadInfo = function (response, field) {
	var repeatInfo = '';
	for (var index in this.users) {
		if (this.users[index]['name'] == field['name']) {
			repeatInfo += ' name ';
		}
		if (this.users[index]['id'] == field['id']) {
			repeatInfo += ' id';
		}
		if (this.users[index]['tel'] == field['tel']) {
			repeatInfo += ' tel';
		}
		if (this.users[index]['email'] == field['email']) {
			repeatInfo += ' email '
		}
	}
	if (repeatInfo == '') {
		this.users.push({name: field['name'], id: field['id'], tel: field['tel'], email: field['email']});
		this.sync();
		return true;
	} else {
		this.send404(response, 'Your infomation (' + repeatInfo.toString() + ') has been register already!');
		return false;
	}
};

pro.findInfo = function (name) {
	for (var index in this.users) {
		if (this.users[index]['name'] == name) {
			return index;
		}
	}
	return -1;
};

pro.get = function (request, response) {
	var values = url.parse(request.url).query; var that = this;
	var index = this.findInfo(queryString.parse(values)['username']);
	if (index == -1) {
		this.send404(response, "The user don't exist!");
	} else {
		this.renderInfo(this.users[index], response);
	}
};


pro.staticFile = function (request, response) {
	var filePath = '../public' + request.url;
	this.serveStatic(response, this.cache, filePath);
};

module.exports = App;
